# Cilium Native 直路由完整部署规范

## 一、前言

文档适用范围：kubeadm 部署的 Kubernetes 集群，当前使用 Calico，目标切换为 Cilium Native Routing，并要求最终带 Hubble UI 浏览器界面。

### 本次环境的真实信息

|**变更日期**|2026\-07\-07|
|---|---|
|**Kubernetes 版本**|v1\.34\.9|
|**master 节点**|192\.168\.10\.200|
|**node 节点**|192\.168\.10\.201|
|**容器运行时**|containerd://2\.2\.5|
|**原 CNI**|Calico v3\.29\.2|
|**原 Pod 网段**|10\.244\.0\.0/16|
|**Service 网段**|10\.96\.0\.0/12|
|**目标 CNI**|Cilium v1\.19\.5|
|**目标模式**|Native Routing（原生直路由）|
|**可视化界面**|Hubble UI|
|**浏览器访问地址**|http://192\.168\.10\.200:31235 或 http://192\.168\.10\.201:31235|

### 先理解这次操作到底在做什么

- Calico 和 Cilium 都是 Kubernetes 的网络插件（CNI）。一个集群同一时刻只应该有一个主用 CNI。

- Calico 当前采用 IPIP 隧道模式，Pod 之间的通信走隧道。

- 本次目标是切换到 Cilium 的 Native Routing 模式，也就是尽量直接走主机路由，不再走 Calico 的 IPIP 隧道。

- 因为要从一个 CNI 完整切换到另一个 CNI，所以切换窗口内会有短暂网络中断。

- 切换完成后，已有业务 Pod 最好重建一次，这样新 Pod 会使用 Cilium 的网络。

- Hubble UI 是 Cilium 的可视化界面。它不是 Kubernetes Dashboard，而是用来看网络流量和网络策略的。

一句话理解：先备份，再删除 Calico，再清理宿主机上的 Calico 网络残留，再安装 Cilium，最后打开 Hubble UI 并验证业务恢复。

### 操作前必须知道的风险

- 这是生产变更动作，不是无损操作。Calico 删除到 Cilium Ready 之间，业务网络会短暂抖动。

- 如果你的集群里用了很多 Calico 的自定义策略对象（例如 GlobalNetworkPolicy），切换前必须单独评估。本文现场没有发现这类对象。

- 如果 master 无法免密登录 node，本手册里涉及 ssh node 的命令会失败，需要先补齐免密。

- 如果节点无法从公网拉取 quay\.io/cilium/\* 镜像，安装阶段会卡住。

## 二、前置操作

### 操作前准备

> 能 SSH 登录 master 节点的账号，本文现场使用的是 root。
> 
> master 节点可以通过 ssh 免密登录 node 节点。
> 
> master 节点已经安装好 kubectl 和 helm。
> 
> 你知道业务低峰时间，并且能接受一次短时间网络切换。
> 
> 

1. 先登录 master，`ssh root@192.168.10.200`

预期结果：成功进入 192\.168\.10\.200 的 shell，提示符变成 master 机器上的 root shell。

2. 确认集群当前状态正常，执行位置：master 节点。

```Shell
kubectl get nodes -o wide
kubectl version
kubectl get pods -A -o wide
```

- 如果 kubectl get nodes 显示节点不是 Ready，先不要切换。

- 如果 kube\-system 里本来就有大量异常 Pod，先处理原始故障，不要边带病边切换。

- 如果 helm version 或 kubectl version 报错，先修工具链。

### 为什么本环境适合切换到 Native Routing

执行位置：master 节点。下面的检查是为了回答一个问题：这套环境能不能不用隧道，而直接用主机路由。

```Shell
kubectl get cm -n kube-system kubeadm-config -o yaml
kubectl get nodes -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.spec.podCIDR}{"\t"}{.status.addresses[?(@.type=="InternalIP")].address}{"\n"}{end}'
ip route
sysctl net.ipv4.ip_forward net.ipv4.conf.all.rp_filter net.ipv4.conf.default.rp_filter
ssh node "ip route; sysctl net.ipv4.ip_forward net.ipv4.conf.all.rp_filter net.ipv4.conf.default.rp_filter"
```

你需要重点看下面几点：

- 两台节点的主机 IP 都在 192\.168\.10\.0/24，这说明它们处于同一二层网络。

- PodSubnet 是 10\.244\.0\.0/16，这个网段后续会继续沿用，不需要改业务访问习惯。

- nodePodCIDR 已经拆成 master=10\.244\.0\.0/24、node=10\.244\.1\.0/24，这对 Cilium 的 kubernetes IPAM 是正常的。

- net\.ipv4\.ip\_forward=1 表示 Linux 已经允许三层转发。

- rp\_filter=2 是宽松模式，通常比严格模式更适合容器网络。

本次现场检查结果：满足 Native Routing 条件，因此采用 Cilium Native Routing，而不是 VXLAN 或 Geneve 隧道模式。

### 备份

执行位置：master 节点。

```SQL
mkdir -p /root/cni-migration-backup
kubectl get all -A -o wide > /root/cni-migration-backup/all-workloads.txt
kubectl get cm -n kube-system kubeadm-config -o yaml > /root/cni-migration-backup/kubeadm-config.yaml
kubectl get ippools.crd.projectcalico.org -A -o yaml > /root/cni-migration-backup/calico-ippools.yaml
kubectl get felixconfigurations.crd.projectcalico.org -A -o yaml > /root/cni-migration-backup/calico-felix.yaml
kubectl get ds,deploy -n kube-system -o yaml > /root/cni-migration-backup/kube-system-network-workloads.yaml
ls -l /root/cni-migration-backup
```

为什么要备份：

- 如果你要回滚到 Calico，这些文件可以帮助你恢复原配置。

- 如果切换后业务异常，这些文件可以帮助你对比切换前后的差异。

- 这是标准变更动作，不能省。

预期结果：/root/cni\-migration\-backup 目录下能看到多个 yaml 和 txt 文件。

## 三、部署流程

### 准备 Cilium 安装参数

#### 添加 Helm 仓库

执行位置：master 节点。

```Shell
helm repo add cilium https://helm.cilium.io/
helm repo update
helm search repo cilium/cilium --versions | head -n 10
```

预期结果：能看到 cilium/cilium 的多个版本号，本文实际使用 1\.19\.5。

#### 写入最终 values\.yaml

执行位置：master 节点。

```YAML
cat >/root/cilium-values.yaml <<'EOF'
k8sServiceHost: 192.168.10.200
k8sServicePort: 6443
 
ipam:
  mode: kubernetes
 
ipv4:
  enabled: true
 
ipv6:
  enabled: false
 
routingMode: native
ipv4NativeRoutingCIDR: 10.244.0.0/16
autoDirectNodeRoutes: true
 
kubeProxyReplacement: false
 
devices: eth0
 
operator:
  replicas: 1
 
hubble:
  enabled: true
  relay:
    enabled: true
  ui:
    enabled: true
    service:
      type: NodePort
      nodePort: 31235
EOF
 
cat /root/cilium-values.yaml
```

下面解释这个配置里最关键的几项：

- k8sServiceHost / k8sServicePort：告诉 Cilium API Server 在哪里。

- ipam\.mode=kubernetes：让 Cilium 使用 Kubernetes 自带的 PodCIDR 分配逻辑。

- routingMode=native：启用原生直路由模式。

- ipv4NativeRoutingCIDR=10\.244\.0\.0/16：告诉 Cilium 整个 Pod 大网段是什么。

- autoDirectNodeRoutes=true：让 Cilium 自动写节点直连路由。

- kubeProxyReplacement=false：本次不替换 kube\-proxy，降低切换复杂度。

- hubble\.enabled=true、relay\.enabled=true、ui\.enabled=true：启用可视化组件。

- ui\.service\.type=NodePort：让浏览器可以直接通过节点 IP 访问 UI。

### 正式切换：删除 Calico

> 从这一步开始，集群网络会进入切换窗口。建议提前通知业务方，确认是低峰时段。
> 
> 

#### 删除 Calico 控制器和节点代理

执行位置：master 节点。

```Shell
kubectl delete deployment calico-kube-controllers -n kube-system --ignore-not-found=true
kubectl delete daemonset calico-node -n kube-system --ignore-not-found=true
kubectl wait --for=delete pod -n kube-system -l k8s-app=calico-node --timeout=180s || true
kubectl wait --for=delete pod -n kube-system -l k8s-app=calico-kube-controllers --timeout=180s || true
```

执行这一步时你会看到什么：

- calico\-kube\-controllers Deployment 被删除。

- calico\-node DaemonSet 被删除。

- 原来的 calico\-node Pod 会退出。

这一步做完后，集群里已经没有 Calico 主控组件了，但宿主机上还残留 CNI 配置和虚拟网卡，所以不能马上结束。

#### 清理 master 节点上的 Calico 宿主机残留

执行位置：master 节点。

```Bash
cp -af /etc/cni/net.d /root/cni-migration-backup/master-net.d.before-cleanup
rm -f /etc/cni/net.d/10-calico.conflist /etc/cni/net.d/calico-kubeconfig
ip route flush proto bird || true
ip link del tunl0 || true
for link in $(ip -o link show | awk -F": " '/cali/ {print $2}' | cut -d@ -f1); do
  ip link del "$link" || true
done
```

每一条命令的含义：

- cp \-af /etc/cni/net\.d \.\.\.：先把旧 CNI 配置备份下来。

- rm \-f 10\-calico\.conflist calico\-kubeconfig：删除旧 Calico CNI 配置文件，否则 kubelet 还可能继续调用它。

- ip route flush proto bird：清掉 Calico/BIRD 下发的路由。

- ip link del tunl0：删除 Calico 的 IPIP 隧道网卡。

- 删除所有 cali\* 网卡：清理 Calico 创建的容器 veth 遗留。

#### 清理 node 节点上的 Calico 宿主机残留

执行位置：master 节点，由 master 通过 ssh node 远程执行。

```Shell
ssh node '
  cp -af /etc/cni/net.d /root/cni-migration-backup/node-net.d.before-cleanup
  rm -f /etc/cni/net.d/10-calico.conflist /etc/cni/net.d/calico-kubeconfig
  ip route flush proto bird || true
  ip link del tunl0 || true
  for link in $(ip -o link show | awk -F": " '"'"'/cali/ {print $2}'"'"' | cut -d@ -f1); do
    ip link del "$link" || true
  done
'
```

说明：这一步和 master 的清理动作一样，只是操作对象变成了 node。

### 安装 Cilium 并启用 Hubble UI

执行位置：master 节点。

```Bash
helm upgrade --install cilium cilium/cilium   --namespace kube-system   --version 1.19.5   -f /root/cilium-values.yaml   --wait   --timeout 10m
 
kubectl rollout status daemonset/cilium -n kube-system --timeout=10m
kubectl rollout status deployment/cilium-operator -n kube-system --timeout=10m
kubectl rollout status deployment/hubble-relay -n kube-system --timeout=10m
kubectl rollout status deployment/hubble-ui -n kube-system --timeout=10m
kubectl get pods -n kube-system -o wide | egrep "cilium|hubble|coredns|kube-proxy"
```

预期结果：

- helm 返回 deployed。

- daemonset/cilium rollout 成功。

- deployment/cilium\-operator rollout 成功。

- deployment/hubble\-relay rollout 成功。

- deployment/hubble\-ui rollout 成功。

如果某个 Pod 卡在 ImagePullBackOff：

- 先检查节点是否能访问 quay\.io。

- 再检查 containerd/crictl 手动拉镜像是否成功。

- 最后再看是否需要配置镜像加速。

### 重启业务 Pod

切换 CNI 之前创建的业务 Pod，网络栈还停留在旧状态。最稳妥的做法是把受影响的工作负载滚动重启一次，让新 Pod 从 Cilium 重新拿地址。

执行位置：master 节点。

```SQL
kubectl rollout restart deployment/coredns -n kube-system
kubectl rollout restart deployment/local-path-provisioner -n local-path-storage
kubectl rollout restart deployment/kong-new-kong -n kong
kubectl rollout restart statefulset/kong-new-postgresql -n kong
 
kubectl rollout status deployment/coredns -n kube-system --timeout=10m
kubectl rollout status deployment/local-path-provisioner -n local-path-storage --timeout=10m
kubectl rollout status deployment/kong-new-kong -n kong --timeout=10m
kubectl rollout status statefulset/kong-new-postgresql -n kong --timeout=10m
```

预期结果：

- coredns 会重建，新的 Pod IP 会落在 10\.244\.0\.0/16 的新分配空间里。

- 本次现场中的 kong 和 postgresql 也都重建成功。

- 如果某个业务设置了 PDB、持久卷或单副本状态应用，滚动重启时间会更长。

### 验证 Cilium 是否真的工作正常

很多人只看 Pod Running 就结束了，这是不够的。必须做跨节点连通、DNS、ClusterIP、Cilium 自身状态四类验证。

执行位置：master 节点。

```Bash
kubectl create namespace cilium-verify --dry-run=client -o yaml | kubectl apply -f -
 
cat <<'EOF' | kubectl apply -f -
apiVersion: v1
kind: Pod
metadata:
  name: curl-master
  namespace: cilium-verify
spec:
  nodeName: master
  tolerations:
  - key: node-role.kubernetes.io/control-plane
    operator: Exists
    effect: NoSchedule
  - key: node-role.kubernetes.io/master
    operator: Exists
    effect: NoSchedule
  containers:
  - name: curl
    image: quay.io/cilium/alpine-curl:v1.10.0
    command: ["sleep", "3600"]
---
apiVersion: v1
kind: Pod
metadata:
  name: curl-node
  namespace: cilium-verify
spec:
  nodeName: node
  containers:
  - name: curl
    image: quay.io/cilium/alpine-curl:v1.10.0
    command: ["sleep", "3600"]
EOF
 
kubectl wait --for=condition=Ready pod/curl-master -n cilium-verify --timeout=5m
kubectl wait --for=condition=Ready pod/curl-node -n cilium-verify --timeout=5m
 
MASTER_IP="$(kubectl get pod curl-master -n cilium-verify -o jsonpath='{.status.podIP}')"
NODE_IP="$(kubectl get pod curl-node -n cilium-verify -o jsonpath='{.status.podIP}')"
echo "master_pod_ip=${MASTER_IP}"
echo "node_pod_ip=${NODE_IP}"
 
kubectl exec -n cilium-verify curl-master -- ping -c 3 "${NODE_IP}"
kubectl exec -n cilium-verify curl-node -- ping -c 3 "${MASTER_IP}"
kubectl exec -n cilium-verify curl-master -- nslookup kubernetes.default.svc.cluster.local.
kubectl exec -n cilium-verify curl-node -- nslookup kubernetes.default.svc.cluster.local.
kubectl exec -n cilium-verify curl-master -- nc -vz kong-new-postgresql.kong.svc.cluster.local 5432
kubectl exec -n cilium-verify curl-node -- nc -vz kong-new-postgresql.kong.svc.cluster.local 5432
 
CILIUM_POD="$(kubectl -n kube-system get pod -l k8s-app=cilium -o jsonpath='{.items[0].metadata.name}')"
kubectl -n kube-system exec "${CILIUM_POD}" -- cilium status --verbose
```

你需要看懂这些验证：

- curl\-master 和 curl\-node：分别固定调度到 master、node，专门用来做网络互通测试。

- ping：验证跨节点 Pod 到 Pod 的三层连通。

- nslookup kubernetes\.default\.svc\.cluster\.local\.：验证 CoreDNS 是否工作正常。

- nc \-vz kong\-new\-postgresql\.\.\. 5432：验证 Service 的 TCP 转发是否正常。

- cilium status \-\-verbose：验证 Cilium agent、routing、health、Hubble 是否都正常。

> 本次现场验证结果：跨节点 ping 成功、DNS 成功、ClusterIP TCP 成功、Cilium status 正常、Cluster health=2/2 reachable。
> 
> 

![image\.png](图片和附件/image%206.png)

![image\.png](图片和附件/image%207.png)

### 打开可视化界面 Hubble UI

因为 values 里把 hubble\-ui Service 暴露成了 NodePort，所以你不需要再执行 kubectl port\-forward。

|**浏览器访问地址 1**|http://192\.168\.10\.200:31235|
|---|---|
|**浏览器访问地址 2**|http://192\.168\.10\.201:31235|
|**Service 名称**|kube\-system/hubble\-ui|
|**Service 类型**|NodePort|
|**NodePort 端口**|31235|

你应该看到的结果：浏览器打开页面后，标题显示为 Hubble UI。

本次现场已经从本机验证过，两个地址都返回 HTTP 200。

> 当前 UI 是内网直出，没有 TLS，也没有登录认证。只适合内网运维场景。如果你要正式开放给更多人使用，建议额外接入 Nginx/Ingress、HTTPS 和认证。
> 
> 

### 清理 Calico 残留资源

执行位置：master 节点。

```SQL
kubectl delete namespace cilium-verify --ignore-not-found=true
kubectl delete configmap calico-config -n kube-system --ignore-not-found=true
kubectl delete serviceaccount calico-cni-plugin calico-kube-controllers calico-node -n kube-system --ignore-not-found=true
kubectl delete clusterrole calico-cni-plugin calico-kube-controllers calico-node --ignore-not-found=true
kubectl delete clusterrolebinding calico-cni-plugin calico-kube-controllers calico-node --ignore-not-found=true
kubectl delete crd   bgpconfigurations.crd.projectcalico.org   bgpfilters.crd.projectcalico.org   bgppeers.crd.projectcalico.org   blockaffinities.crd.projectcalico.org   caliconodestatuses.crd.projectcalico.org   clusterinformations.crd.projectcalico.org   felixconfigurations.crd.projectcalico.org   globalnetworkpolicies.crd.projectcalico.org   globalnetworksets.crd.projectcalico.org   hostendpoints.crd.projectcalico.org   ipamblocks.crd.projectcalico.org   ipamconfigs.crd.projectcalico.org   ipamhandles.crd.projectcalico.org   ippools.crd.projectcalico.org   ipreservations.crd.projectcalico.org   kubecontrollersconfigurations.crd.projectcalico.org   networkpolicies.crd.projectcalico.org   networksets.crd.projectcalico.org   tiers.crd.projectcalico.org   --ignore-not-found=true
 
rm -f /opt/cni/bin/calico /opt/cni/bin/calico-ipam
ssh node "rm -f /opt/cni/bin/calico /opt/cni/bin/calico-ipam"
```

为什么还要做这一步：

- 避免集群里同时残留两套 CNI 的 RBAC 和 CRD。

- 避免以后排障时误认为 Calico 还在生效。

- 让宿主机 /opt/cni/bin 只保留 cilium\-cni，更容易维护。

## 四、Cilium UI操作

### 选择 Namespace 进入主界面

http://192\.168\.10\.201:31235/

页面提示 `To begin select one of the namespaces`，点击下拉框 `Choose namespace`，下拉会列出集群所有 Namespace：`default` / `kube-system` / `kong` / `local-path-storage`

- 只想看某个业务，选 `kong`，只展示 Kong 网关流量

- 观测集群底层组件，点击 kube\-system

选中后页面自动跳转，进入 Hubble UI 流量可视化主面板

![image\.png](图片和附件/image%205.png)

![image\.png](图片和附件/image%202.png)

### 图形介绍

![image\.png](图片和附件/image%203.png)

1. 节点含义

    - world：外部客户端（你本地浏览器），代表集群外部访问流量

    - hubble\-ui（kube\-system）：图形界面 Pod，监听 `8081/TCP`

    - hubble\-relay（kube\-system）：流量中继服务，负责转发 Cilium 采集的全集群流量，监听 `4245/TCP`

    - 虚线框：限定当前观测命名空间 `kube-system`，所有流量均在该命名空间内或与外部互通

2. 链路逻辑（完整访问链路）

    - 本地浏览器（world）→ `hubble-ui:8081`：你访问页面的 HTTP 流量

    - `hubble-ui` → `hubble-relay:4245`：UI 向后端中继服务拉取集群流量日志

    - `hubble-relay` → 各节点 Cilium Agent：收集全节点网络流数据（拓扑未展示底层 cilium 节点）

3. 流量状态标识

    所有连线与下方表格 `Verdict` 字段均为 forwarded（绿色）：代表所有 TCP 连接均被 Cilium 网络策略放行，无拦截、丢包。 右上角指标：`11.8 flows/s · 2/2 nodes`

    - 每秒采集 11\.8 条网络流日志

    - 集群 2 个节点的 Cilium Agent 均正常上报流量数据

4. 菜单栏

![image\.png](图片和附件/image%201.png)

    支持多维度联合筛选，常用过滤语法：

    ```Shell
    # 只看被丢弃的流量
    verdict=dropped
    # 只看目标端口5432（PostgreSQL数据库）
    destination-port=5432
    # 只看kong命名空间流量
    namespace=kong
    # 过滤源Pod标签
    pod=kong-new-kong
    ```

    按钮功能

    - Any verdict：下拉可切换只看放行 / 只看丢弃流量，排查网络拦截时常用

    - Visual：当前激活拓扑图视图；切换可切换到纯表格日志视图（Flows）

### 日志分析

![image\.png](图片和附件/image.png)

当前观测命名空间：`kube-system`，所有日志仅记录该命名空间流量。

1. 日志字段含义（当前展示列）

2. 日志里两条核心流量链路

    1. 外部客户端 → hubble\-ui:8081 就是你电脑浏览器访问 `192.168.10.201:31235` 的 HTTP 页面访问流量，持续不断刷新产生大量日志。

    2. hubble\-ui → hubble\-relay:4245 UI 面板向后端中继服务拉取全集群流量数据的内部通信，用来渲染拓扑、填充下方日志表格。

### 部署新应用

参照[Rocky9搭建K8S集群 X86\_ESXI环境](https://thisxiaok.feishu.cn/wiki/HRrpw9WV3ifUwukI9X7c3U3WnJd?fromScene=spaceOverview)hivision\_idphotos部署方案

选择命名空间 已形成拓扑

![image\.png](图片和附件/image%204.png)

## 五、结论及风险预估

### 切换完成后应该是什么样子

|**节点状态**|kubectl get nodes 显示 master 和 node 都是 Ready|
|---|---|
|**CNI 配置文件**|两台节点都应该是 /etc/cni/net\.d/05\-cilium\.conflist|
|**CNI 二进制**|两台节点 /opt/cni/bin 中保留 cilium\-cni，不再保留 calico / calico\-ipam|
|**Cilium Agent**|kube\-system 中每个节点各有一个 cilium Pod|
|**Hubble UI**|kube\-system 中存在 hubble\-ui Pod，且 Service 为 NodePort|
|**浏览器访问**|192\.168\.10\.200:31235 和 192\.168\.10\.201:31235 都能打开 UI|

### 本次现场的最终结果

- Calico 已完全切换为 Cilium。

- Cilium 版本为 1\.19\.5。

- 路由模式为 Native Routing。

- Hubble Relay 和 Hubble UI 已启用。

- UI 已对外提供浏览器访问地址。

- 业务 Pod 已完成重建并通过验证。

### 如果你照着做，最容易出错的点

- 忘记备份。建议无论测试环境还是生产环境都先做备份。

- 没有确认 node 可以被 master 免密 ssh。这样清理 node 宿主机时会卡住。

- 删除了 Calico，却没有删除 /etc/cni/net\.d/10\-calico\.conflist。这样 kubelet 还会尝试调用旧插件。

- 只装了 cilium，没有重启业务 Pod。这样旧 Pod 可能继续带着旧网络状态。

- 只看 kubectl get pods，不做 ping、DNS、Service 的真实验证。

- 把 Hubble UI 暴露到公网而没有认证或 TLS。

### 常见故障排查

#### Cilium Pod 起不来

- 检查 helm upgrade 输出。

- 检查 kubectl describe pod \-n kube\-system 。

- 检查节点是否能拉取 quay\.io/cilium/cilium:v1\.19\.5。

- 检查 /etc/cni/net\.d 是否已经切换成 05\-cilium\.conflist。

#### Hubble UI 打不开

- 先执行 kubectl get svc \-n kube\-system hubble\-ui，确认类型是 NodePort，端口是 31235。

- 再执行 kubectl get pods \-n kube\-system \| grep hubble，确认 relay 和 ui 都是 Running。

- 检查浏览器所在机器到 192\.168\.10\.200:31235 或 192\.168\.10\.201:31235 的网络是否放通。

- 如果节点系统有防火墙，还要确认 31235 已放通。

#### 业务 Pod 不能访问 Service

- 先看 kube\-proxy 是否正常，因为本次没有启用 kube\-proxy replacement。

- 再看 CoreDNS 是否正常。

- 最后进入测试 Pod 做 nslookup 和 nc \-vz 验证。

### 回滚思路

如果切换失败，需要回到 Calico，大方向是反着做：先卸载 Cilium，再恢复 Calico。

- 使用 /root/cni\-migration\-backup 中的备份确认原始 Calico 配置。

- 卸载 Cilium Helm Release。

- 删除 /etc/cni/net\.d/05\-cilium\.conflist 和 /opt/cni/bin/cilium\-cni。

- 重新部署 Calico v3\.29\.2。

- 重启业务 Pod，重新验证 Pod 通信、DNS、Service。

### 最终生效的 values\.yaml

```YAML
k8sServiceHost: 192.168.10.200
k8sServicePort: 6443
 
ipam:
  mode: kubernetes
 
ipv4:
  enabled: true
 
ipv6:
  enabled: false
 
routingMode: native
ipv4NativeRoutingCIDR: 10.244.0.0/16
autoDirectNodeRoutes: true
 
kubeProxyReplacement: false
 
devices: eth0
 
operator:
  replicas: 1
 
hubble:
  enabled: true
  relay:
    enabled: true
  ui:
    enabled: true
    service:
      type: NodePort
      nodePort: 31235
```

### 一句话结论

如果你是第一次做这类切换，可以把这次操作记成 8 个动作：确认环境适合直路由、备份、写 values、删 Calico、清宿主机、装 Cilium、启用 UI、做验证。只要每一步都确认成功，再继续下一步，整体风险是可控的。

